<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class User_Model extends CI_Model {

    public function GetAllUserList() {
        $this->db->select('tbl_user.*,tbl_user_type.user_name');
        $this->db->from('tbl_user');
        $this->db->join('tbl_user_type', 'tbl_user.utype=tbl_user_type.id');
        $this->db->where('tbl_user.id !=', 1);
        $this->db->order_by('tbl_user.first_name');
        $query = $this->db->get();
        return $query->result();
    }

    public function AddUserProcess($userDataArray) {
        $this->db->insert('tbl_user', $userDataArray);
    }

}
