<H1>Hi</H1>


<?php echo $userdata('email') ?> 