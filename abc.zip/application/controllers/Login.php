<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

    public function index() {
        $this->load->view('login');
    }
    
    public function auth_user() {
        
            $this->load->model('Auth_model');
            $this->form_validation->set_rules('email', 'Eamil Id', 'required|valid_email|xss_clean');
            $this->form_validation->set_rules('password', 'Password', 'required');
            
            if ($this->form_validation->run() == TRUE) {
                $this->Auth_model->ProcessAuthentication($this->input->post('email'), $this->input->post('password'));
            
            } else {

                $this->session->set_flashdata('msg', 'Whoops!  Invalid email or password.');
                redirect('login');
            }
    }

}
