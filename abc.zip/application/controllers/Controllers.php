<?php

class Controllers extends CI_Controller {

    function __construct() {
        parent::__construct();
        // $this->load->model('Auth_model');
    }

    public function index() {
        
        $this->load->view('login');
       
    }

}
