<?php

defined('BASEPATH') OR exit('No direct script access allowed');

require_once('Authcontroller.php');

class Welcome extends MY_Controller {

    public function index() {

        $this->render_template('test',$data); 
        // echo "<pre>";
        // print_r($this->session->all_userdata());
        // echo "</pre>";
        // exit();
    
    }

}
